        _/    _/_/    _/_/_/_/_/                              _/       
           _/    _/      _/      _/_/    _/    _/    _/_/_/  _/_/_/    
      _/  _/  _/_/      _/    _/    _/  _/    _/  _/        _/    _/   
     _/  _/    _/      _/    _/    _/  _/    _/  _/        _/    _/    
    _/    _/_/  _/    _/      _/_/      _/_/_/    _/_/_/  _/    _/     
   _/                                                                  
_/

Created by David Kaneda <http://www.davidkaneda.com>
Documentation and issue tracking on Google Code <http://code.google.com/p/jqtouch/>

Special thanks to Jonathan Stark <http://jonathanstark.com/>
and pinch/zoom <http://www.pinchzoom.com/>

(c) 2009 by jQTouch project members.
See LICENSE.txt for license.

If you use jQTouch, please consider supporting its development:
http://bit.ly/support-jqt